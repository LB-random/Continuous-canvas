"""Retain vector paths and paint small live-stroke increments, not whole scenes."""
from decimal import Decimal, localcontext
import weakref
import base64
import math

from PyQt5.QtCore import QPointF, QRectF, Qt
from PyQt5.QtGui import QColor, QImage, QPainter, QPainterPath, QPolygonF, QTransform

from .model import PRECISION, RasterPatch, clip_polygon, dec


def polygon_path(polygons):
    path = QPainterPath()
    path.setFillRule(Qt.WindingFill)
    for polygon in polygons:
        path.addPolygon(QPolygonF([QPointF(x, y) for x, y in polygon]))
        path.closeSubpath()
    return path


class VectorRenderer:
    def __init__(self):
        self.paths = weakref.WeakKeyDictionary()
        self.images = weakref.WeakKeyDictionary()

    def path_for(self, stroke, start=None):
        cached = self.paths.get(stroke)
        if cached is None:
            path, count = QPainterPath(), 0
            path.setFillRule(Qt.WindingFill)
        else:
            path, count = cached
        rule = Qt.OddEvenFill if getattr(stroke, "fill_rule", None) == "odd_even" else Qt.WindingFill
        path.setFillRule(rule)
        chunk = None
        if count < len(stroke.points):
            chunk = polygon_path(stroke.polygons(count))
            chunk.setFillRule(rule)
            path.addPath(chunk)
            self.paths[stroke] = (path, len(stroke.points))
        if start is None or start == 0:
            return path
        if start == count and chunk is not None:
            return chunk
        return polygon_path(stroke.polygons(start))

    def draw(self, painter, stroke, camera, width, height, start=None):
        if isinstance(stroke, RasterPatch):
            return self.draw_raster(painter, stroke, camera, width, height)
        with localcontext(PRECISION):
            ratio = stroke.unit / camera.unit
            ox = (stroke.origin[0] - camera.x) / camera.unit + dec(width / 2)
            oy = (stroke.origin[1] - camera.y) / camera.unit + dec(height / 2)
            l, t, r, b = stroke.bounds
            left, top = ox + dec(l) * ratio, oy + dec(t) * ratio
            right, bottom = ox + dec(r) * ratio, oy + dec(b) * ratio
            if right < 0 or bottom < 0 or left > width or top > height:
                return
            # Keep all transformed coordinates within Qt's raster range. The
            # high precision clipped renderer remains the fallback at deep zoom.
            native = (Decimal("1e-7") < ratio < Decimal("1e6") and
                      min(left, top) > -16000 and max(right, bottom) < 16000)
            if native:
                path = self.path_for(stroke, start)
                painter.save()
                try:
                    painter.translate(float(ox), float(oy))
                    painter.scale(float(ratio), float(ratio))
                    painter.fillPath(path, QColor(stroke.color))
                finally:
                    painter.restore()
            else:
                path = polygon_path(stroke.screen_polygons(camera, width, height))
                if getattr(stroke, "fill_rule", None) == "odd_even":
                    path.setFillRule(Qt.OddEvenFill)
                if not path.isEmpty():
                    painter.fillPath(path, QColor(stroke.color))

    def draw_raster(self, painter, patch, camera, width, height):
        with localcontext(PRECISION):
            ratio = patch.unit / camera.unit
            ox = (patch.origin[0] - camera.x) / camera.unit + dec(width / 2)
            oy = (patch.origin[1] - camera.y) / camera.unit + dec(height / 2)
            p0, p1, _, p3 = patch.contours[0]
            a = dec(p1[0] - p0[0]) * ratio / patch.pixel_width
            b = dec(p1[1] - p0[1]) * ratio / patch.pixel_width
            c = dec(p3[0] - p0[0]) * ratio / patch.pixel_height
            d = dec(p3[1] - p0[1]) * ratio / patch.pixel_height
            tx, ty = ox + dec(p0[0]) * ratio, oy + dec(p0[1]) * ratio
            determinant = a * d - b * c
            if not determinant:
                return
            corners = [(-tx, -ty), (dec(width) - tx, -ty),
                       (dec(width) - tx, dec(height) - ty), (-tx, dec(height) - ty)]
            pixels = [((d * x - c * y) / determinant, (-b * x + a * y) / determinant) for x, y in corners]
            left = max(0, math.floor(min(p[0] for p in pixels)))
            top = max(0, math.floor(min(p[1] for p in pixels)))
            right = min(patch.pixel_width, math.ceil(max(p[0] for p in pixels)))
            bottom = min(patch.pixel_height, math.ceil(max(p[1] for p in pixels)))
            if left >= right or top >= bottom:
                return
            image = self.images.get(patch)
            if image is None:
                image = QImage.fromData(base64.b64decode(patch.png), "PNG")
                if image.isNull():
                    raise ValueError("Could not decode a native brush patch.")
                self.images[patch] = image
            crop_tx, crop_ty = tx + dec(left) * a + dec(top) * c, ty + dec(left) * b + dec(top) * d
            if max(abs(a), abs(b), abs(c), abs(d)) < 4000:
                crop = image.copy(left, top, right - left, bottom - top)
                painter.save()
                try:
                    painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
                    painter.setTransform(QTransform(float(a), float(b), float(c), float(d), float(crop_tx), float(crop_ty)), True)
                    painter.drawImage(0, 0, crop)
                finally:
                    painter.restore()
            else:
                # At extreme enlargement only a handful of source pixels can
                # intersect the view. Clip their quads with Decimal precision.
                painter.save()
                try:
                    # Adjacent source pixels share exact boundaries. Separate
                    # antialiased fills would introduce translucent seam lines.
                    painter.setRenderHint(QPainter.Antialiasing, False)
                    for y in range(top, bottom):
                        for x in range(left, right):
                            color = image.pixelColor(x, y)
                            if color.alpha() == 0:
                                continue
                            polygon = [(tx + dec(px) * a + dec(py) * c, ty + dec(px) * b + dec(py) * d)
                                       for px, py in [(x, y), (x + 1, y), (x + 1, y + 1), (x, y + 1)]]
                            clipped = clip_polygon(polygon, Decimal(0), Decimal(0), dec(width), dec(height))
                            if len(clipped) >= 3:
                                painter.fillPath(polygon_path([[(float(px), float(py)) for px, py in clipped]]), color)
                finally:
                    painter.restore()
