"""Feature-gated bridge to Krita's actual scripted brush painting API.

Calls remain on Krita's GUI thread. Scratch documents belong only to this bridge;
the user's document and layer pixels are never painted on.
"""
import base64
import math
import time
from decimal import localcontext

from PyQt5.QtCore import QBuffer, QIODevice, QPointF, QRect
from PyQt5.QtGui import QColor, QImage, QImageWriter, QPainterPath

from .model import PRECISION, RasterPatch, dec


class NativeBrushBridge:
    def __init__(self, app=None, color_factory=None, reuse=False):
        if app is None:
            from krita import Krita
            app = Krita.instance()
        self.app = app
        self.color_factory = color_factory
        self.reuse = reuse
        self.document = None
        self._uses = 0
        self._retained_bytes = 0
        self.last_timings = {}

    @staticmethod
    def same_preset(left, right):
        if left is right:
            return True
        if left is None or right is None:
            return False
        try:
            return (left.type(), left.name(), left.filename()) == (right.type(), right.name(), right.filename())
        except AttributeError:
            return left == right

    def prepare(self):
        if not self.reuse:
            return
        if self.document is not None:
            width_method = getattr(self.document, "width", None)
            if callable(width_method) and width_method() <= 0:
                self.document = None
        if self.document is not None and (self._uses >= 4 or self._retained_bytes >= 16 * 1024 * 1024):
            self.close()
        if self.document is None:
            self.document = self.app.createDocument(4096, 4096, "Continuous Canvas — native brush scratch", "RGBA", "U8",
                                                    "sRGB-elle-V2-srgbtrc.icc", 100.0)
            if self.document is None:
                raise RuntimeError("Krita could not prepare a brush scratch document.")
            self._uses = 0
            self._retained_bytes = 0

    def close(self):
        document, self.document = self.document, None
        if document is not None:
            document.waitForDone()
            document.setModified(False)
            document.close()

    def render(self, stroke, preset=None):
        started = time.perf_counter()
        self.last_timings = {}
        from krita import ManagedColor
        window = self.app.activeWindow()
        if window is None:
            raise ValueError("Open a Krita window first.")
        padding = max(64, math.ceil(stroke.width * 4 + 32))
        left = math.floor(min(p[0] for p in stroke.points)) - padding
        top = math.floor(min(p[1] for p in stroke.points)) - padding
        width = math.ceil(max(p[0] for p in stroke.points)) - left + padding + 1
        height = math.ceil(max(p[1] for p in stroke.points)) - top + padding + 1
        if max(width, height) > 4096:
            raise ValueError("Native stroke is too large for a 4096 px scratch patch. Use a smaller brush or shorter stroke.")
        if self.reuse:
            self.prepare()
            doc = self.document
        else:
            doc = self.app.createDocument(width, height, "Continuous Canvas — native brush scratch", "RGBA", "U8",
                                          "sRGB-elle-V2-srgbtrc.icc", 100.0)
        if doc is None:
            raise RuntimeError("Krita could not create a native brush scratch document.")
        self.last_timings["document_ms"] = (time.perf_counter() - started) * 1000
        view, saved, node = None, None, None
        preset_changed = False
        extras = []
        try:
            node = doc.createNode("Native brush ink", "paintlayer")
            if not callable(getattr(node, "paintPath", None)):
                raise RuntimeError("This Krita build has no Node.paintPath brush API. Use a Krita 5.3 build with scripted painting support.")
            if not doc.rootNode().addChildNode(node, None):
                raise RuntimeError("Could not create the native brush layer.")
            view = window.activeView()
            if view is None:
                view = window.addView(doc)
                if view is None:
                    raise RuntimeError("Krita requires an active document view to supply brush resources.")
            saved = (view.currentBrushPreset(), view.brushSize(), view.foregroundColor(),
                     view.eraserMode(), view.currentBlendingMode())
            for getter, setter in (("paintingOpacity", "setPaintingOpacity"),
                                   ("paintingFlow", "setPaintingFlow"), ("brushRotation", "setBrushRotation")):
                if callable(getattr(view, getter, None)) and callable(getattr(view, setter, None)):
                    extras.append((setter, getattr(view, getter)()))
            if preset is not None and not self.same_preset(preset, saved[0]):
                view.setCurrentBrushPreset(preset)
                preset_changed = True
            if view.currentBrushPreset() is None:
                raise ValueError("Select a brush preset in Krita or load a preset in this window first.")
            preset_name = view.currentBrushPreset().name()
            view.setBrushSize(stroke.width)
            color = self.color_factory(QColor(stroke.color)) if self.color_factory else ManagedColor.fromQColor(QColor(stroke.color))
            view.setForeGroundColor(color)
            view.setEraserMode(False)
            view.setCurrentBlendingMode("normal")
            mode = "paintPath: uniform pressure"
            paint_started = time.perf_counter()
            self.last_timings["setup_ms"] = (paint_started - started) * 1000 - self.last_timings["document_ms"]
            samples = None
            if callable(getattr(node, "paintPolylineStroke", None)):
                try:
                    from krita import StrokePoint
                    samples = [StrokePoint(QPointF(x - left, y - top), pressure) for x, y, pressure in stroke.points]
                except ImportError:
                    pass
            if samples is not None:
                node.paintPolylineStroke(samples, "ForegroundColor")
                mode = "paintPolylineStroke: per-point pressure"
            else:
                path = QPainterPath()
                path.moveTo(stroke.points[0][0] - left, stroke.points[0][1] - top)
                for x, y, _ in stroke.points[1:]:
                    path.lineTo(x - left, y - top)
                if len(stroke.points) == 1:
                    node.paintLine(path.currentPosition(), path.currentPosition(), 1.0, 1.0)
                else:
                    node.paintPath(path, "ForegroundColor", "None")
            doc.waitForDone()
            self.last_timings["paint_ms"] = (time.perf_counter() - paint_started) * 1000
            capture_started = time.perf_counter()
            bounds = node.bounds().intersected(QRect(0, 0, width, height))
            if bounds.isEmpty():
                raise RuntimeError("The selected preset produced no visible ink on a transparent layer. Try a normal paint preset.")
            raw = bytes(node.pixelData(bounds.x(), bounds.y(), bounds.width(), bounds.height()))
            if len(raw) != bounds.width() * bounds.height() * 4:
                raise RuntimeError("Krita returned unexpected native brush pixel data.")
            image = QImage(raw, bounds.width(), bounds.height(), bounds.width() * 4, QImage.Format_ARGB32).copy()
            output = QBuffer()
            output.open(QIODevice.WriteOnly)
            writer = QImageWriter(output, b"PNG")
            writer.setCompression(1)
            if not writer.write(image):
                raise RuntimeError("Could not encode native brush pixels.")
            self._retained_bytes += len(raw)
            self.last_timings["capture_ms"] = (time.perf_counter() - capture_started) * 1000
            with localcontext(PRECISION):
                origin = (stroke.origin[0] + dec(bounds.x() + left) * stroke.unit,
                          stroke.origin[1] + dec(bounds.y() + top) * stroke.unit)
            return RasterPatch(origin, stroke.unit, image.width(), image.height(),
                               base64.b64encode(bytes(output.data())).decode("ascii"), preset=preset_name, mode=mode)
        finally:
            try:
                if saved is not None:
                    old_preset, size, color, eraser, blend = saved
                    if preset_changed and old_preset is not None:
                        view.setCurrentBrushPreset(old_preset)
                    view.setBrushSize(size)
                    view.setForeGroundColor(color)
                    view.setEraserMode(eraser)
                    view.setCurrentBlendingMode(blend)
                    for setter, value in extras:
                        getattr(view, setter)(value)
            finally:
                doc.waitForDone()
                if self.reuse:
                    if node is not None:
                        removed = node.remove()
                        if removed is False:
                            self._uses = 4  # Recycle rather than retaining an unremovable layer.
                        doc.waitForDone()
                    doc.setModified(False)
                    self._uses += 1
                else:
                    doc.setModified(False)
                    doc.close()
                self.last_timings["total_ms"] = (time.perf_counter() - started) * 1000
