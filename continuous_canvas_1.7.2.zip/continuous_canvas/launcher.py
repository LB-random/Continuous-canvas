from PyQt5.QtWidgets import QLabel, QPushButton, QVBoxLayout, QWidget
from krita import DockWidget, Extension, Krita
from .window import CanvasWindow

_windows = {}


def launch():
    owner = Krita.instance().activeWindow()
    if owner is None:
        return
    parent = owner.qwindow()
    key = int(parent.winId())
    window = _windows.get(key)
    if window is None:
        window = CanvasWindow(parent)
        _windows[key] = window
        window.destroyed.connect(lambda: _windows.pop(key, None))
    window.show()
    window.raise_()
    window.activateWindow()


class CanvasLauncher(Extension):
    def setup(self):
        pass

    def createActions(self, window):
        action = window.createAction("continuous_canvas_open", "Open Continuous Canvas", "tools/scripts")
        action.triggered.connect(launch)


class CanvasDock(DockWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Continuous Canvas")
        body = QWidget(self)
        layout = QVBoxLayout(body)
        label = QLabel("One custom vector surface. Draw, pan, and zoom directly at every scale.")
        label.setWordWrap(True)
        layout.addWidget(label)
        button = QPushButton("Open Continuous Canvas")
        button.clicked.connect(launch)
        layout.addWidget(button)
        note = QLabel("Uses its own pen tools and .ccanvas.json projects. Your normal Krita documents remain separate.")
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch()
        self.setWidget(body)

    def canvasChanged(self, canvas):
        pass
