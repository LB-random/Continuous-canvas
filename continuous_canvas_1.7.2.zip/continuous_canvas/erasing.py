"""Subtract a round eraser sweep from vectors or native patch alpha."""
import base64
import math
import threading
from decimal import localcontext

from PyQt5.QtCore import QBuffer, QIODevice, QPointF, Qt, QObject, QRunnable, QThreadPool, pyqtSignal
from PyQt5.QtGui import QColor, QImage, QImageWriter, QPainter, QPainterPath, QPainterPathStroker, QPen, QTransform

from .model import Camera, PRECISION, RasterPatch, VectorShape


def erase_segment(stroke, camera, width, height, start, end, diameter, renderer):
    sweep = local_sweep(stroke, camera, width, height, start, end, diameter)
    return erase_path(stroke, sweep, renderer) if sweep is not None else stroke


def local_sweep(stroke, camera, width, height, start, end, diameter):
    with localcontext(PRECISION):
        a = camera.world(start.x(), start.y(), width, height)
        b = camera.world(end.x(), end.y(), width, height)
        ax, ay = [float((v - o) / stroke.unit) for v, o in zip(a, stroke.origin)]
        bx, by = [float((v - o) / stroke.unit) for v, o in zip(b, stroke.origin)]
        radius = float(camera.unit / stroke.unit) * diameter / 2
    l, t, r, bot = stroke.bounds
    if max(ax, bx) + radius < l or min(ax, bx) - radius > r or max(ay, by) + radius < t or min(ay, by) - radius > bot:
        return None
    if not all(math.isfinite(v) for v in (ax, ay, bx, by, radius)) or radius <= 0:
        return None
    sweep = QPainterPath()
    if ax == bx and ay == by:
        sweep.addEllipse(QPointF(ax, ay), radius, radius)
    else:
        line = QPainterPath(QPointF(ax, ay))
        line.lineTo(bx, by)
        outline = QPainterPathStroker()
        outline.setWidth(radius * 2)
        outline.setCapStyle(Qt.RoundCap)
        outline.setJoinStyle(Qt.RoundJoin)
        sweep = outline.createStroke(line)
    return sweep


def erase_path(stroke, sweep, renderer):
    if isinstance(stroke, RasterPatch):
        p0, p1, _, p3 = stroke.contours[0]
        transform = QTransform((p1[0] - p0[0]) / stroke.pixel_width, (p1[1] - p0[1]) / stroke.pixel_width,
                               (p3[0] - p0[0]) / stroke.pixel_height, (p3[1] - p0[1]) / stroke.pixel_height,
                               p0[0], p0[1])
        inverse, valid = transform.inverted()
        if not valid:
            return stroke
        image = QImage.fromData(base64.b64decode(stroke.png), "PNG").convertToFormat(QImage.Format_ARGB32_Premultiplied)
        painter = QPainter(image)
        try:
            painter.setRenderHint(QPainter.Antialiasing)
            painter.setCompositionMode(QPainter.CompositionMode_Clear)
            painter.fillPath(inverse.map(sweep), Qt.black)
        finally:
            painter.end()
        buffer = QBuffer()
        buffer.open(QIODevice.WriteOnly)
        writer = QImageWriter(buffer, b"PNG")
        writer.setCompression(1)
        if not writer.write(image):
            raise ValueError("Could not save erased brush pixels.")
        return RasterPatch(stroke.origin, stroke.unit, stroke.pixel_width, stroke.pixel_height,
                           base64.b64encode(bytes(buffer.data())).decode("ascii"), stroke.contours, stroke.preset, stroke.mode)
    path = renderer.path_for(stroke)
    if not path.intersects(sweep):
        return stroke
    remaining = path.subtracted(sweep)
    return vector_result(stroke, remaining)


def vector_result(stroke, remaining):
    contours = [[(p.x(), p.y()) for p in polygon] for polygon in remaining.toSubpathPolygons() if len(polygon) >= 3]
    # A degenerate contour represents a fully erased item without introducing a
    # new file type, and keeps one replacement transaction for the whole gesture.
    return VectorShape(stroke.origin, stroke.unit, stroke.color, contours or [[(0, 0)] * 3])


class EraserGesture:
    """Cheap incremental screen preview; edit each affected object once at release."""
    def __init__(self, camera, width, height, image):
        self.camera, self.width, self.height = Camera(camera.x, camera.y, camera.unit), width, height
        self.image = image.copy()
        self.segments = []
        self.bounds = None

    def add(self, start, end, diameter):
        start, end = QPointF(start), QPointF(end)
        if self.segments and start == end and self.segments[-1][1] == end:
            return
        self.segments.append((start, end, diameter))
        radius = diameter / 2
        bounds = (min(start.x(), end.x()) - radius, min(start.y(), end.y()) - radius,
                  max(start.x(), end.x()) + radius, max(start.y(), end.y()) + radius)
        if self.bounds is None:
            self.bounds = bounds
        else:
            l, t, r, b = self.bounds
            self.bounds = (min(l, bounds[0]), min(t, bounds[1]), max(r, bounds[2]), max(b, bounds[3]))
        painter = QPainter(self.image)
        try:
            painter.setRenderHint(QPainter.Antialiasing)
            painter.setPen(QPen(QColor("white"), diameter, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
            if start == end:
                painter.setPen(Qt.NoPen)
                painter.setBrush(QColor("white"))
                painter.drawEllipse(start, radius, radius)
            else:
                painter.drawLine(start, end)
        finally:
            painter.end()

    def replacements(self, strokes, renderer, cancelled=None):
        from .tools import world_bounds
        if self.bounds is None:
            return []
        l, t, r, b = self.bounds
        left, top = self.camera.world(l, t, self.width, self.height)
        right, bottom = self.camera.world(r, b, self.width, self.height)
        result = []
        for index, stroke in enumerate(strokes):
            if cancelled is not None and cancelled.is_set():
                raise RuntimeError("Erasure cancelled; drawing unchanged.")
            sl, st, sr, sb = world_bounds(stroke)
            if sr < left or sl > right or sb < top or st > bottom:
                continue
            combined = QPainterPath()
            combined.setFillRule(Qt.WindingFill)
            remaining = None if isinstance(stroke, RasterPatch) else renderer.path_for(stroke)
            touched = False
            batch = 0
            for start, end, diameter in self.segments:
                if cancelled is not None and cancelled.is_set():
                    raise RuntimeError("Erasure cancelled; drawing unchanged.")
                sweep = local_sweep(stroke, self.camera, self.width, self.height, start, end, diameter)
                if sweep is not None:
                    combined.addPath(sweep)
                    batch += 1
                # Avoid a single boolean operation against thousands of
                # overlapping capsules. Keep each vector subtraction bounded.
                if remaining is not None and batch >= 16:
                    if remaining.intersects(combined):
                        remaining = remaining.subtracted(combined)
                        touched = True
                    combined = QPainterPath()
                    combined.setFillRule(Qt.WindingFill)
                    batch = 0
            if remaining is not None:
                if not combined.isEmpty() and remaining.intersects(combined):
                    remaining = remaining.subtracted(combined)
                    touched = True
                if touched:
                    result.append((index, vector_result(stroke, remaining)))
                continue
            if not combined.isEmpty():
                erased = erase_path(stroke, combined, renderer)
                if erased is not stroke:
                    result.append((index, erased))
        return result


class EraserSignals(QObject):
    completed = pyqtSignal(object)


class EraserJob(QRunnable):
    """Only private Qt paths/images and immutable model snapshots; no Krita API."""
    def __init__(self, session, strokes, ratio):
        super().__init__()
        self.session, self.strokes, self.ratio = session, tuple(strokes), ratio
        self.signals = EraserSignals()
        self.cancelled = threading.Event()

    def run(self):
        from .rendering import VectorRenderer
        result = {}
        try:
            renderer = VectorRenderer()
            replacements = self.session.replacements(self.strokes, renderer, self.cancelled)
            image = QImage(self.session.image.size(), QImage.Format_RGB32)
            image.setDevicePixelRatio(self.ratio)
            image.fill(QColor("white"))
            painter = QPainter(image)
            try:
                painter.setRenderHint(QPainter.Antialiasing)
                changed = dict(replacements)
                for index, stroke in enumerate(self.strokes):
                    if self.cancelled.is_set():
                        raise RuntimeError("Erasure cancelled; drawing unchanged.")
                    renderer.draw(painter, changed.get(index, stroke), self.session.camera,
                                  self.session.width, self.session.height)
            finally:
                painter.end()
            if self.cancelled.is_set():
                raise RuntimeError("Erasure cancelled; drawing unchanged.")
            result = {"replacements": replacements, "image": image}
        except Exception as error:
            result = {"error": str(error)}
        self.signals.completed.emit(result)


# Application lifetime: a dialog must never destroy/wait on a running pool.
ERASER_POOL = QThreadPool()
ERASER_POOL.setMaxThreadCount(1)
