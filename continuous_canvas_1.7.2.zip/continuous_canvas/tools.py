"""Geometry and editing operations for the custom vector tools."""
import math
from decimal import localcontext

from .model import PRECISION, Stroke, dec


def shape_points(tool, dx, dy, constrain=False):
    if constrain:
        if tool == "Line":
            angle = round(math.atan2(dy, dx) / (math.pi / 4)) * (math.pi / 4)
            length = math.hypot(dx, dy)
            dx, dy = math.cos(angle) * length, math.sin(angle) * length
        else:
            side = max(abs(dx), abs(dy))
            dx, dy = math.copysign(side, dx), math.copysign(side, dy)
    if tool == "Line":
        return [(0, 0, 1), (dx, dy, 1)]
    if tool == "Rectangle":
        return [(x, y, 1) for x, y in [(0, 0), (dx, 0), (dx, dy), (0, dy), (0, 0)]]
    if tool == "Ellipse":
        count = max(48, min(512, math.ceil(math.pi * max(abs(dx), abs(dy)) / 4)))
        return [(dx / 2 + dx / 2 * math.cos(i * math.tau / count),
                 dy / 2 + dy / 2 * math.sin(i * math.tau / count), 1) for i in range(count + 1)]
    raise ValueError("Unknown shape tool.")


def world_bounds(stroke):
    with localcontext(PRECISION):
        l, t, r, b = map(dec, stroke.bounds)
        x, y = stroke.origin
        return x + l * stroke.unit, y + t * stroke.unit, x + r * stroke.unit, y + b * stroke.unit


def translated(stroke, dx, dy):
    with localcontext(PRECISION):
        origin = (stroke.origin[0] + dx, stroke.origin[1] + dy)
    return clone_geometry(stroke, origin, stroke.unit)


def clone_geometry(stroke, origin, unit, angle=0, mirror=False):
    from .model import RasterPatch, VectorShape
    radians = math.radians(angle)
    c, s = math.cos(radians), math.sin(radians)
    def rotate(point):
        x, y = point[:2]
        if mirror:
            x = -x
        return x * c - y * s, x * s + y * c
    if isinstance(stroke, RasterPatch):
        contours = [[rotate(point) for point in contour] for contour in stroke.contours]
        return RasterPatch(origin, unit, stroke.pixel_width, stroke.pixel_height, stroke.png,
                           contours, stroke.preset, stroke.mode)
    if isinstance(stroke, VectorShape):
        contours = [[rotate(point) for point in contour] for contour in stroke.contours]
        return VectorShape(origin, unit, stroke.color, contours)
    points = [(*rotate(point), point[2]) for point in stroke.points]
    return Stroke(origin, unit, stroke.width, stroke.color, points)


def transformed(stroke, pivot, scale=1, angle=0, mirror=False):
    c, s = dec(math.cos(math.radians(angle))), dec(math.sin(math.radians(angle)))
    with localcontext(PRECISION):
        x, y = stroke.origin[0] - pivot[0], stroke.origin[1] - pivot[1]
        if mirror:
            x = -x
        origin = (pivot[0] + (x * c - y * s) * dec(scale),
                  pivot[1] + (x * s + y * c) * dec(scale))
        unit = stroke.unit * dec(scale)
    return clone_geometry(stroke, origin, unit, angle, mirror)
