"""One editable vector surface hosted by Krita. Requires PyQt5."""
import math
import time
from decimal import localcontext
from pathlib import Path

from PyQt5.QtCore import QEvent, QEventLoop, QPointF, QRectF, QSize, Qt, QTimer, pyqtSlot
from PyQt5.QtGui import QColor, QFont, QIcon, QImage, QKeySequence, QPainter, QPainterPath, QPen, QPixmap
from PyQt5.QtWidgets import (QApplication, QCheckBox, QColorDialog, QComboBox, QDialog, QFileDialog,
                             QActionGroup, QFontDialog, QHBoxLayout, QInputDialog, QLabel,
                             QMessageBox, QProgressDialog, QPushButton, QShortcut, QSpinBox, QToolBar,
                             QVBoxLayout, QWidget)

from .model import Camera, Paper, PRECISION, Stroke, VectorShape, dec
from .tools import shape_points, transformed, translated, world_bounds
from .navigation import FrameRenderer
from .rendering import VectorRenderer

VERSION = "1.7.2"
TOOLS = ["Select", "Move", "Pen", "Native brush", "Detail eraser", "Stroke eraser", "Line", "Rectangle", "Ellipse",
         "Text", "Color picker", "Pan", "Zoom"]


class Surface(QWidget):
    def __init__(self, owner):
        super().__init__(owner)
        self.owner = owner
        self.setMinimumSize(320, 240)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setAttribute(Qt.WA_AcceptTouchEvents, True)
        self.setMouseTracking(True)
        self.pending = None
        self.origin_screen = None
        self.panning = False
        self.last = None
        self.space = False
        self.tablet_active = False
        self.touch_active = False
        self.touch_state = None
        self.erase_indices = set()
        self._detail_session = None
        self._erase_busy = False
        self.selected = set()
        self._gesture_tool = None
        self._native_preset = None
        self._native_live = None
        self._native_failure = None
        self._shape_start = None
        self._marquee_start = None
        self._marquee_end = None
        self._move_originals = []
        self._move_preview = []
        self._drag_world = None
        self.renderer = VectorRenderer()
        self._background = None
        self._background_scene = None
        self._background_revision = -1
        self._background_exclusions = None
        self._live_image = None
        self._live_key = None
        self._live_count = 0
        self._navigating = False
        self._nav_settled = False
        self._nav_source = None
        self._nav_camera = None
        self._nav_base = None
        self._nav_generation = 0
        self._nav_worker = FrameRenderer(self)
        self._nav_worker.completed.connect(self._navigation_ready)
        self._nav_refresh = QTimer(self)
        self._nav_refresh.setInterval(70)
        self._nav_refresh.timeout.connect(self._request_navigation_frame)
        self._nav_finish = QTimer(self)
        self._nav_finish.setSingleShot(True)
        self._nav_finish.setInterval(150)
        self._nav_finish.timeout.connect(self._settle_navigation)

    @property
    def paper(self):
        return self.owner.paper

    def render(self, painter, width, height):
        painter.fillRect(0, 0, width, height, QColor("white"))
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setPen(Qt.NoPen)
        for index, stroke in enumerate(self.paper.strokes):
            if index in self.erase_indices:
                continue
            self.renderer.draw(painter, stroke, self.paper.camera, width, height)
        if self.pending is not None:
            self.renderer.draw(painter, self.pending, self.paper.camera, width, height)

    def _new_image(self, ratio):
        image = QImage(math.ceil(self.width() * ratio), math.ceil(self.height() * ratio), QImage.Format_RGB32)
        image.setDevicePixelRatio(ratio)
        image.fill(QColor("white"))
        return image

    def _paint_stroke(self, image, stroke, start=None):
        painter = QPainter(image)
        try:
            painter.setRenderHint(QPainter.Antialiasing, True)
            painter.setPen(Qt.NoPen)
            self.renderer.draw(painter, stroke, self.paper.camera, self.width(), self.height(), start)
        finally:
            painter.end()

    def _view_image(self):
        if self._detail_session is not None:
            return self._detail_session.image
        if self._navigating:
            # Explicit exports/tests/starting a stroke require an exact frame.
            self.cancel_navigation()
        camera = self.paper.camera
        ratio = self.devicePixelRatioF()
        scene = (id(self.paper), camera.x, camera.y, camera.unit, self.width(), self.height(), ratio)
        native_ink = {session.stroke for session in self.native_overlays()}
        native_exclusions = frozenset(i for i, s in enumerate(self.paper.strokes) if s in native_ink) if native_ink else frozenset()
        exclusions = (frozenset(self.erase_indices) | frozenset(index for index, _ in self._move_preview) |
                      native_exclusions)
        revision = self.paper.revision
        if (scene != self._background_scene or revision != self._background_revision or
                exclusions != self._background_exclusions):
            append_only = (scene == self._background_scene and not exclusions and
                           not self._background_exclusions and self._background is not None and
                           revision == self._background_revision + 1 and self.paper.last_change and
                           self.paper.last_change[0] == "add")
            if append_only:
                self._paint_stroke(self._background, self.paper.last_change[1])
            else:
                self._background = self._new_image(ratio)
                painter = QPainter(self._background)
                try:
                    painter.setRenderHint(QPainter.Antialiasing, True)
                    painter.setPen(Qt.NoPen)
                    for index, stroke in enumerate(self.paper.strokes):
                        if index not in exclusions:
                            self.renderer.draw(painter, stroke, camera, self.width(), self.height())
                finally:
                    painter.end()
            self._background_scene = scene
            self._background_revision = revision
            self._background_exclusions = exclusions
            self._live_key = None
        if self.pending is None or (self._native_live is not None and self._native_live.frame is not None):
            self._live_image = None
            self._live_key = None
            return self._background
        key = (scene, revision, exclusions, id(self.pending))
        if key != self._live_key:
            # Qt's implicit image sharing copies pixels only on the first write.
            self._live_image = QImage(self._background)
            self._live_key = key
            self._live_count = 0
        count = len(self.pending.points)
        if count > self._live_count:
            self._paint_stroke(self._live_image, self.pending, self._live_count)
            self._live_count = count
        return self._live_image

    def _navigation_base(self):
        return (id(self.paper), self.paper.revision, self.width(), self.height(), self.devicePixelRatioF())

    def _start_navigation(self):
        if not self._navigating:
            self._nav_source = QImage(self._view_image())
            self._nav_camera = Camera(*self.paper.camera.data())
            self._nav_base = self._navigation_base()
            self._nav_generation += 1
            self._navigating = True
            self._nav_refresh.start()
        self._nav_settled = False
        self._nav_finish.start()

    def _adopt_navigation_frame(self):
        camera = self.paper.camera
        self._background = self._nav_source
        self._background_scene = (id(self.paper), camera.x, camera.y, camera.unit,
                                  self.width(), self.height(), self.devicePixelRatioF())
        self._background_revision = self.paper.revision
        self._background_exclusions = frozenset()
        self._live_key = None

    def cancel_navigation(self):
        if (self._navigating and self._nav_base == self._navigation_base() and
                self._nav_camera.data() == self.paper.camera.data()):
            self._adopt_navigation_frame()
        self._navigating = False
        self._nav_source = None
        self._nav_camera = None
        self._nav_generation += 1
        self._nav_refresh.stop()
        self._nav_finish.stop()
        self._nav_worker.cancel()

    def _request_navigation_frame(self):
        if not self._navigating:
            return
        if self._nav_base != self._navigation_base():
            self.cancel_navigation()
            self.update()
            return
        if self._nav_camera.data() == self.paper.camera.data():
            if self._nav_settled:
                self.cancel_navigation()
                self.update()
            return
        ticket = (self._nav_generation, self._nav_base)
        self._nav_worker.start(ticket, tuple(self.paper.strokes), Camera(*self.paper.camera.data()),
                               self.width(), self.height(), self.devicePixelRatioF(), self.renderer)

    def _settle_navigation(self):
        self._nav_settled = True
        self._request_navigation_frame()

    @pyqtSlot(object)
    def _navigation_ready(self, result):
        if not self._navigating or result["ticket"] != (self._nav_generation, self._navigation_base()):
            return
        if result.get("error"):
            self.cancel_navigation()
            self.owner.report("Navigation refresh failed: {}".format(result["error"]))
            self.update()
            return
        if result["image"] is not None:
            self._nav_source = result["image"]
            self._nav_camera = result["camera"]
        self._request_navigation_frame()
        self.update()

    def _paint_navigation(self, painter):
        if self._nav_base != self._navigation_base():
            self.cancel_navigation()
            painter.drawImage(0, 0, self._view_image())
            return
        painter.fillRect(self.rect(), QColor("white"))
        with localcontext(PRECISION):
            camera, source = self.paper.camera, self._nav_camera
            scale = source.unit / camera.unit
            tx = (source.x - camera.x) / camera.unit + dec(self.width() / 2) * (1 - scale)
            ty = (source.y - camera.y) / camera.unit + dec(self.height() / 2) * (1 - scale)
            if dec("1e-6") <= scale <= dec("1e6") and abs(tx) < dec("1e9") and abs(ty) < dec("1e9"):
                painter.save()
                try:
                    painter.translate(float(tx), float(ty))
                    painter.scale(float(scale), float(scale))
                    painter.drawImage(0, 0, self._nav_source)
                finally:
                    painter.restore()

    def paintEvent(self, event):
        painter = QPainter(self)
        try:
            if self._navigating:
                self._paint_navigation(painter)
            else:
                painter.drawImage(0, 0, self._view_image())
            self.paint_native_frames(painter)
            self._paint_tools_overlay(painter)
        except Exception as error:
            self.owner.report("Drawing error: {}".format(error))
        finally:
            painter.end()

    def _begin(self, point, pressure=1.0, input_event=None):
        self.setFocus()
        self.cancel_navigation()
        tool = self.owner.tool.currentText()
        self._gesture_tool = tool
        self._native_failure = None
        if tool == "Native brush":
            self._native_preset = self.owner.selected_native_preset()
        if tool == "Color picker":
            image = self._view_image()
            ratio = image.devicePixelRatio()
            x, y = int(point.x() * ratio), int(point.y() * ratio)
            if 0 <= x < image.width() and 0 <= y < image.height():
                self.owner.set_ink(image.pixelColor(x, y))
            return
        if tool == "Text":
            self._gesture_tool = None
            self.owner.insert_text(point)
            return
        if tool == "Zoom":
            active, self.tablet_active = self.tablet_active, False
            try:
                self.zoom(0.5 if QApplication.keyboardModifiers() & Qt.ControlModifier else 2, point)
            finally:
                self.tablet_active = active
            return
        if tool == "Pan":
            self.panning = True
            self.last = QPointF(point)
            self.setCursor(Qt.ClosedHandCursor)
            return
        if tool in ("Select", "Move"):
            self._begin_selection(point, tool)
            return
        if tool == "Stroke eraser":
            self.erase_indices = set()
            self._erase(point)
            return
        if tool == "Detail eraser":
            self.last = QPointF(point)
            self._detail_erase(point, point)
            return
        x, y = self.paper.camera.world(point.x(), point.y(), self.width(), self.height())
        pressure = max(0.05, min(1.0, pressure)) if self.owner.pressure.isChecked() else 1.0
        self.pending = Stroke((x, y), self.paper.camera.unit, self.owner.size.value(),
                              self.owner.ink.name(), [(0, 0, pressure)])
        self.origin_screen = QPointF(point)
        if tool == "Native brush":
            # Never construct a hidden Scratchpad or inject events into a
            # private native child: this caused process-level heap corruption.
            self.owner.report("Native compatibility mode: preview now, native texture after pen-up.")
        if tool in ("Line", "Rectangle", "Ellipse"):
            self._shape_start = self.pending
        self.update()

    def _move(self, point, pressure=1.0, input_event=None):
        if self._gesture_tool == "Pan" and self.last is not None:
            self._start_navigation()
            self.paper.camera.pan(point.x() - self.last.x(), point.y() - self.last.y())
            self.paper.dirty = True
            self.owner.changed()
        elif self._marquee_start is not None:
            self._marquee_end = QPointF(point)
        elif self._gesture_tool == "Detail eraser" and self.last is not None:
            self._detail_erase(self.last, point)
            self.last = QPointF(point)
        elif self._move_originals:
            with localcontext(PRECISION):
                wx, wy = self.paper.camera.world(point.x(), point.y(), self.width(), self.height())
                dx, dy = wx - self._drag_world[0], wy - self._drag_world[1]
                self._move_preview = [(index, translated(stroke, dx, dy)) for index, stroke in self._move_originals]
        elif self._shape_start is not None:
            dx, dy = point.x() - self.origin_screen.x(), point.y() - self.origin_screen.y()
            points = shape_points(self._gesture_tool, dx, dy, bool(QApplication.keyboardModifiers() & Qt.ShiftModifier))
            base = self._shape_start
            if self.owner.fill_shapes.isChecked() and self._gesture_tool != "Line":
                self.pending = VectorShape(base.origin, base.unit, base.color, [[p[:2] for p in points]])
            else:
                self.pending = Stroke(base.origin, base.unit, base.width, base.color, points)
            self._live_key = None
        elif self._gesture_tool == "Stroke eraser" and self.last is not None:
            distance = math.hypot(point.x() - self.last.x(), point.y() - self.last.y())
            steps = min(200, max(1, math.ceil(distance / 4)))
            for i in range(1, steps + 1):
                fraction = i / steps
                self._erase(QPointF(self.last.x() + (point.x() - self.last.x()) * fraction,
                                   self.last.y() + (point.y() - self.last.y()) * fraction))
        elif self.pending is not None:
            x, y = point.x() - self.origin_screen.x(), point.y() - self.origin_screen.y()
            previous = self.pending.points[-1]
            if math.hypot(x - previous[0], y - previous[1]) >= 0.5:
                pressure = max(0.05, min(1.0, pressure)) if self.owner.pressure.isChecked() else 1.0
                self.pending.append(x, y, pressure)
            if self._native_live is not None:
                try:
                    self._native_live.feed("move", point, input_event)
                except Exception as error:
                    self._native_failure = str(error)
                    self._native_live.dispose()
                    self.owner._native_sessions.discard(self._native_live)
                    self._native_live = None
        self.update()

    def _erase(self, point):
        radius = self.owner.size.value() / 2
        for i, stroke in enumerate(self.paper.strokes):
            if i not in self.erase_indices and stroke.hit(self.paper.camera, point.x(), point.y(),
                                                         self.width(), self.height(), radius):
                self.erase_indices.add(i)
        self.update()

    def _detail_erase(self, start, end):
        from .erasing import EraserGesture
        try:
            if self._detail_session is None:
                self._detail_session = EraserGesture(self.paper.camera, self.width(), self.height(), self._view_image())
            self._detail_session.add(start, end, self.owner.size.value())
        except Exception as error:
            self.owner.report("Could not erase this detail: " + str(error))
            return
        self.update()

    def finish(self):
        if self._erase_busy:
            return
        erase_result = None
        if self._detail_session is not None:
            session, self._detail_session = self._detail_session, None
            source_paper, source_revision = self.paper, self.paper.revision
            from .erasing import EraserJob, ERASER_POOL
            job = EraserJob(session, self.paper.strokes, self.devicePixelRatioF())
            loop = QEventLoop(self)
            progress = QProgressDialog("Applying eraser… Your drawing is kept intact until this finishes.", "Cancel", 0, 0, self.owner)
            progress.setWindowTitle("Applying eraser")
            progress.setWindowModality(Qt.WindowModal)
            progress.setMinimumDuration(0)
            progress.setAutoClose(False)
            result = []
            def completed(value):
                result.append(value)
                loop.quit()
            job.signals.completed.connect(completed, Qt.QueuedConnection)
            def cancel():
                job.cancelled.set()
                progress.setLabelText("Cancelling erasure… Your drawing will stay unchanged.")
                progress.setCancelButton(None)
                progress.show()
            progress.canceled.connect(cancel)
            self._erase_busy = True
            self._detail_session = session  # Keep the fast preview during processing.
            try:
                progress.show()
                ERASER_POOL.start(job)
                loop.exec_()
                erase_result = result[0]
                if job.cancelled.is_set():
                    erase_result = {"error": "Erasure cancelled; drawing unchanged."}
                elif self.paper is not source_paper or self.paper.revision != source_revision:
                    erase_result = {"error": "Canvas changed while erasing; erasure discarded."}
                self._move_preview = erase_result.get("replacements", [])
            finally:
                self._erase_busy = False
                self._detail_session = None
                progress.canceled.disconnect(cancel)
                progress.close()
                progress.deleteLater()
                loop.deleteLater()
        native = self._gesture_tool == "Native brush"
        live, self._native_live = self._native_live, None
        native_message = None
        if self._marquee_start is not None:
            a = self.paper.camera.world(self._marquee_start.x(), self._marquee_start.y(), self.width(), self.height())
            b = self.paper.camera.world(self._marquee_end.x(), self._marquee_end.y(), self.width(), self.height())
            left, top, right, bottom = min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1])
            for stroke in self.paper.strokes:
                l, t, r, bot = world_bounds(stroke)
                if left <= l and top <= t and right >= r and bottom >= bot:
                    self.selected.add(stroke)
        if self._move_preview:
            self.paper.replace(self._move_preview)
            self.selected = ({stroke for _, stroke in self._move_preview}
                             if self._gesture_tool != "Detail eraser" else set())
        self._move_originals = []
        self._move_preview = []
        self._marquee_start = self._marquee_end = None
        self._shape_start = None
        self._gesture_tool = None
        if self.pending is not None:
            stroke, self.pending = self.pending, None
            try:
                if live is not None:
                    self.paper.add(stroke)
                    live.finish()
                    stroke = None
                elif native and self._native_failure:
                    native_message = "Native brush failed: {}. Vector recovery ink retained.".format(self._native_failure)
                elif native:
                    # Short taps must be visible before the compatibility API
                    # blocks to paint the completed stroke.
                    self.pending = stroke
                    self.repaint()
                    self.pending = None
                    try:
                        stroke = self.owner.render_native(stroke, self._native_preset)
                        native_message = "Native brush: {} · {}".format(stroke.preset, stroke.mode)
                        elapsed = self.owner._native_timings.get("interaction_ms")
                        if elapsed is not None:
                            native_message += " · {:.0f} ms".format(elapsed)
                    except Exception as error:
                        native_message = "Native brush failed: {}. Stroke kept as vector recovery ink.".format(error)
                if stroke is not None:
                    self.paper.add(stroke)
            except Exception as error:
                self.owner.report(str(error))
        if self.erase_indices:
            self.paper.erase(self.erase_indices)
            self.erase_indices = set()
        self.origin_screen = None
        if (erase_result and "image" in erase_result and session.width == self.width()
                and session.height == self.height() and session.camera.data() == self.paper.camera.data()):
            self._background = erase_result["image"]
            camera = self.paper.camera
            self._background_scene = (id(self.paper), camera.x, camera.y, camera.unit,
                                      self.width(), self.height(), self.devicePixelRatioF())
            self._background_revision = self.paper.revision
            self._background_exclusions = frozenset()
            self._live_key = None
        self.owner.changed()
        if erase_result and "error" in erase_result:
            self.owner.report(erase_result["error"])
        if native_message:
            self.owner.report(native_message)
        self.update()

    def native_overlays(self):
        if not self.owner._native_sessions:
            return []
        result = []
        for session in self.owner._native_sessions:
            if session.paper is not self.paper or session.frame is None:
                continue
            if session.stroke is not self.pending and session.stroke not in self.paper.strokes:
                continue
            with localcontext(PRECISION):
                scale = session.stroke.unit / self.paper.camera.unit
                if dec("0.125") <= scale <= 8:
                    result.append(session)
        return sorted(result, key=lambda session: len(self.paper.strokes) if session.stroke is self.pending else self.paper.strokes.index(session.stroke))

    def paint_native_frames(self, painter):
        for session in self.native_overlays():
            with localcontext(PRECISION):
                camera = self.paper.camera
                rect, stroke = session.frame_rect, session.stroke
                x = stroke.origin[0] + dec(rect.x() - session.padding - session.start_point.x()) * stroke.unit
                y = stroke.origin[1] + dec(rect.y() - session.padding - session.start_point.y()) * stroke.unit
                tx = (x - camera.x) / camera.unit + dec(self.width() / 2)
                ty = (y - camera.y) / camera.unit + dec(self.height() / 2)
                scale = stroke.unit / camera.unit
                if abs(tx) > 32000 or abs(ty) > 32000:
                    continue
                painter.save()
                try:
                    painter.translate(float(tx), float(ty))
                    painter.scale(float(scale), float(scale))
                    painter.drawImage(0, 0, session.frame)
                finally:
                    painter.restore()

    def _begin_selection(self, point, tool):
        self.selected.intersection_update(self.paper.strokes)
        shift = bool(QApplication.keyboardModifiers() & Qt.ShiftModifier)
        hit = next((s for s in reversed(self.paper.strokes)
                    if s.hit(self.paper.camera, point.x(), point.y(), self.width(), self.height(), 5)), None)
        if tool == "Select":
            if not shift:
                self.selected.clear()
            if hit is not None:
                if shift and hit in self.selected:
                    self.selected.remove(hit)
                else:
                    self.selected.add(hit)
            else:
                self._marquee_start = self._marquee_end = QPointF(point)
        elif hit is not None:
            if hit not in self.selected:
                self.selected = {hit}
            self._move_originals = [(i, s) for i, s in enumerate(self.paper.strokes) if s in self.selected]
            self._drag_world = self.paper.camera.world(point.x(), point.y(), self.width(), self.height())
        self.update()

    def _paint_tools_overlay(self, painter):
        if self._gesture_tool == "Detail eraser":
            return
        if not self.selected and not self._move_preview and self._marquee_start is None:
            return
        for _, stroke in self._move_preview:
            self.renderer.draw(painter, stroke, self.paper.camera, self.width(), self.height())
        painter.save()
        try:
            painter.setPen(QPen(QColor("#3a86ff"), 1, Qt.DashLine))
            painter.setBrush(Qt.NoBrush)
            if self._marquee_start is not None:
                painter.drawRect(QRectF(self._marquee_start, self._marquee_end).normalized())
            visible_selection = [s for s in self.paper.strokes if s in self.selected]
            if self._move_preview:
                visible_selection = [s for _, s in self._move_preview]
            if visible_selection:
                bounds = [world_bounds(s) for s in visible_selection]
                with localcontext(PRECISION):
                    camera = self.paper.camera
                    l = (min(b[0] for b in bounds) - camera.x) / camera.unit + dec(self.width() / 2)
                    t = (min(b[1] for b in bounds) - camera.y) / camera.unit + dec(self.height() / 2)
                    r = (max(b[2] for b in bounds) - camera.x) / camera.unit + dec(self.width() / 2)
                    b = (max(b[3] for b in bounds) - camera.y) / camera.unit + dec(self.height() / 2)
                    if r >= 0 and b >= 0 and l <= self.width() and t <= self.height():
                        l, t, r, b = max(-2, float(l)), max(-2, float(t)), min(self.width() + 2, float(r)), min(self.height() + 2, float(b))
                        painter.drawRect(QRectF(l, t, r - l, b - t))
        finally:
            painter.restore()

    def mousePressEvent(self, event):
        if self.tablet_active or self.touch_active:
            event.accept()
            return
        self.last = event.localPos()
        self.setFocus()
        if event.button() == Qt.MiddleButton or (self.space and event.button() == Qt.LeftButton):
            self.finish()
            self.panning = True
            self.setCursor(Qt.ClosedHandCursor)
        elif event.button() == Qt.LeftButton:
            self.owner.run(lambda: self._begin(event.localPos(), input_event=event))
        event.accept()

    def mouseMoveEvent(self, event):
        if self.tablet_active or self.touch_active:
            event.accept()
            return
        point = event.localPos()
        if self.panning and self.last is not None:
            self._start_navigation()
            self.paper.camera.pan(point.x() - self.last.x(), point.y() - self.last.y())
            self.paper.dirty = True
            self.owner.changed()
            self.update()
        elif event.buttons() & Qt.LeftButton:
            self.owner.run(lambda: self._move(point, input_event=event))
        self.last = point
        event.accept()

    def mouseReleaseEvent(self, event):
        if self.tablet_active or self.touch_active:
            event.accept()
            return
        if event.button() in (Qt.LeftButton, Qt.MiddleButton):
            if (self.pending is not None or self._move_originals or self._marquee_start is not None
                    or self._gesture_tool == "Detail eraser"):
                self.owner.run(lambda: self._move(event.localPos(), input_event=event))
            self.finish()
            self.panning = False
            self.setCursor(Qt.OpenHandCursor if self.space else Qt.CrossCursor)
        event.accept()

    def tabletEvent(self, event):
        point = event.posF()
        if event.type() == QEvent.TabletPress:
            self.tablet_active = True
            self.last = point
            self.owner.run(lambda: self._begin(point, event.pressure(), event))
        elif event.type() == QEvent.TabletMove and self.tablet_active:
            self.owner.run(lambda: self._move(point, event.pressure(), event))
            self.last = point
        elif event.type() == QEvent.TabletRelease:
            self.owner.run(lambda: self._move(point, max(0.05, event.pressure()), event))
            self.finish()
            self.last = None
            self.tablet_active = False
            self.panning = False
        event.accept()

    def zoom(self, factor, point=None):
        if self.pending is not None or self._detail_session is not None or self.tablet_active or self.erase_indices or self._move_originals or self._marquee_start is not None:
            return
        point = point or QPointF(self.width() / 2, self.height() / 2)
        self._start_navigation()
        self.paper.camera.zoom(factor, point.x(), point.y(), self.width(), self.height())
        self.paper.dirty = True
        self.owner.changed()
        self.update()

    def wheelEvent(self, event):
        delta = event.angleDelta().y() or event.pixelDelta().y()
        if delta:
            factor = 1.2 ** max(-8.0, min(8.0, delta / 120.0))
            self.zoom(factor, event.posF())
        event.accept()

    def event(self, event):
        if event.type() in (QEvent.TouchBegin, QEvent.TouchUpdate, QEvent.TouchEnd, QEvent.TouchCancel):
            self.finish()
            points = [p.pos() for p in event.touchPoints() if p.state() != Qt.TouchPointReleased]
            if event.type() in (QEvent.TouchEnd, QEvent.TouchCancel) or not points:
                self.touch_active = False
                self.touch_state = None
            else:
                self.touch_active = True
                center = points[0] if len(points) == 1 else (points[0] + points[1]) / 2
                distance = math.hypot(points[0].x() - points[1].x(), points[0].y() - points[1].y()) if len(points) >= 2 else None
                if self.touch_state is not None:
                    previous, old_distance, old_count = self.touch_state
                    if len(points) == old_count:
                        self._start_navigation()
                        if distance and old_distance and old_distance > 1:
                            self.paper.camera.zoom(max(0.01, min(100.0, distance / old_distance)),
                                                   previous.x(), previous.y(), self.width(), self.height())
                        self.paper.camera.pan(center.x() - previous.x(), center.y() - previous.y())
                        self.paper.dirty = True
                        self.owner.changed()
                        self.update()
                self.touch_state = (QPointF(center), distance, len(points))
            event.accept()
            return True
        return super().event(event)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Space:
            self.space = True
            self.setCursor(Qt.OpenHandCursor)
            event.accept()
        else:
            super().keyPressEvent(event)

    def keyReleaseEvent(self, event):
        if event.key() == Qt.Key_Space:
            self.space = False
            self.setCursor(Qt.CrossCursor)
            event.accept()
        else:
            super().keyReleaseEvent(event)

    def focusOutEvent(self, event):
        self.finish()
        self.panning = False
        self.space = False
        self.tablet_active = False
        self.touch_active = False
        self.touch_state = None
        self.last = None
        super().focusOutEvent(event)

    def resizeEvent(self, event):
        if hasattr(self, "pending") and (self.pending is not None or self.erase_indices or self._detail_session is not None):
            self.finish()
        super().resizeEvent(event)


class CanvasWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.setWindowFlags(Qt.Window | Qt.WindowMinMaxButtonsHint | Qt.WindowCloseButtonHint)
        self.setWindowTitle("Continuous Canvas " + VERSION)
        self.resize(1200, 850)
        self.paper = Paper()
        self._native_sessions = set()
        self._native_resources = {}
        self._native_bridge = None
        self._native_timings = {}
        self._native_prepare_timer = QTimer(self)
        self._native_prepare_timer.setSingleShot(True)
        self._native_prepare_timer.timeout.connect(self.prepare_native)
        self._native_host_document = None
        self.ink = QColor("#202634")
        self.text_font = QFont("Sans Serif", 32)
        self.autosave_timer = QTimer(self)
        self.autosave_timer.setSingleShot(True)
        self.autosave_timer.setInterval(1200)
        self.autosave_timer.timeout.connect(self._autosave)
        layout = QVBoxLayout(self)
        files = QHBoxLayout()
        self._button(files, "New", self.new)
        self._button(files, "Open…", self.open)
        self._button(files, "Save", self.save)
        self._button(files, "Save as…", lambda: self.save(True))
        self._button(files, "Export view PNG…", self.export_png)
        self._button(files, "Open raster copy in Krita", self.open_raster_copy)
        self.autosave = QCheckBox("Autosave")
        self.autosave.setChecked(True)
        self.autosave.toggled.connect(lambda enabled: self.autosave_timer.stop() if not enabled else self.changed())
        files.addWidget(self.autosave)
        files.addStretch()
        layout.addLayout(files)
        tools = QHBoxLayout()
        self.tool = QComboBox()
        self.tool.addItems(TOOLS)
        self.tool.setCurrentText("Pen")
        tools.addWidget(self.tool)
        self.color_button = self._button(tools, "Ink color…", self.color)
        self.fill_shapes = QCheckBox("Fill shapes")
        tools.addWidget(self.fill_shapes)
        tools.addWidget(QLabel("Size on screen"))
        self.size = QSpinBox()
        self.size.setRange(1, 200)
        self.size.setValue(5)
        self.size.setSuffix(" px")
        tools.addWidget(self.size)
        self.pressure = QCheckBox("Pen pressure")
        self.pressure.setChecked(True)
        tools.addWidget(self.pressure)
        self._button(tools, "Undo", self.undo)
        self._button(tools, "Redo", self.redo)
        self._button(tools, "−", lambda: self.surface.zoom(0.5))
        self._button(tools, "+", lambda: self.surface.zoom(2))
        tools.addStretch()
        layout.addLayout(tools)
        toolbar = QToolBar("Canvas tools", self)
        toolbar.setToolButtonStyle(Qt.ToolButtonTextOnly)
        self.tool_actions = {}
        group = QActionGroup(self)
        group.setExclusive(True)
        for name in TOOLS:
            action = toolbar.addAction(name)
            action.setCheckable(True)
            action.setChecked(name == "Pen")
            group.addAction(action)
            action.triggered.connect(lambda checked=False, name=name: self.tool.setCurrentText(name))
            self.tool_actions[name] = action
        layout.addWidget(toolbar)
        native_tools = QHBoxLayout()
        native_tools.addWidget(QLabel("Native preset"))
        self.native_presets = QComboBox()
        self.native_presets.addItem("Current preset in Krita", None)
        self.native_presets.setMinimumWidth(240)
        self.native_presets.setIconSize(QSize(48, 48))
        self.native_presets.currentIndexChanged.connect(lambda index: self.run(self.activate_native_preset))
        native_tools.addWidget(self.native_presets)
        self._button(native_tools, "Load Krita presets", self.load_native_presets)
        self._button(native_tools, "Timing details", self.native_timing_details)
        native_note = QLabel("Native brush: compatibility mode. Native texture appears after pen-up. Krita thumbnails retained.")
        native_note.setWordWrap(True)
        native_tools.addWidget(native_note, 1)
        layout.addLayout(native_tools)
        editing = QHBoxLayout()
        self._button(editing, "Select all", self.select_all)
        self._button(editing, "Deselect", self.deselect)
        self._button(editing, "Delete selected", self.delete_selected)
        self._button(editing, "Duplicate", self.duplicate_selected)
        self._button(editing, "Scale…", self.scale_selected)
        self._button(editing, "Rotate…", self.rotate_selected)
        self._button(editing, "Mirror", lambda: self.transform_selected(mirror=True))
        self._button(editing, "Text font…", self.choose_font)
        editing.addStretch()
        layout.addLayout(editing)
        marks = QHBoxLayout()
        self.bookmarks = QComboBox()
        self.bookmarks.setMinimumWidth(180)
        marks.addWidget(self.bookmarks)
        self._button(marks, "Go to bookmark", self.go_bookmark)
        self._button(marks, "Add bookmark…", self.bookmark)
        self._button(marks, "Home view", self.home)
        marks.addStretch()
        layout.addLayout(marks)
        self.surface = Surface(self)
        self.surface.setCursor(Qt.CrossCursor)
        layout.addWidget(self.surface, 1)
        self.tool.currentTextChanged.connect(self.tool_changed)
        self.status = QLabel()
        self.status.setWordWrap(True)
        self.status.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.status)
        hint = QLabel("Custom vector tools · Shift: constrain shapes / add selection · Ctrl+click with Zoom: zoom out · Wheel: zoom · Space + drag: pan")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self._shortcuts = []
        for keys, callback in [("Ctrl+S", self.save), ("Ctrl+O", self.open),
                               ("Ctrl+N", self.new), ("Ctrl+Z", self.undo), ("Ctrl+Shift+Z", self.redo)]:
            shortcut = QShortcut(QKeySequence(keys), self)
            shortcut.activated.connect(lambda cb=callback: self.run(cb))
            self._shortcuts.append(shortcut)
        self.changed()
        self.set_ink(self.ink)
        for keys, callback in [("Ctrl+A", self.select_all), ("Delete", self.delete_selected),
                               ("Ctrl+D", self.duplicate_selected)]:
            shortcut = QShortcut(QKeySequence(keys), self.surface)
            shortcut.setContext(Qt.WidgetShortcut)
            shortcut.activated.connect(lambda cb=callback: self.run(cb))
            self._shortcuts.append(shortcut)

    def run(self, callback):
        try:
            callback()
        except Exception as error:
            self.report("{}: {}".format(type(error).__name__, error))

    def _button(self, layout, text, callback):
        button = QPushButton(text)
        button.clicked.connect(lambda checked=False: self.run(callback))
        layout.addWidget(button)
        return button

    def set_ink(self, color):
        self.ink = QColor(color)
        swatch = QPixmap(18, 18)
        swatch.fill(self.ink)
        self.color_button.setIcon(QIcon(swatch))
        self.color_button.setToolTip(self.ink.name())

    def load_native_presets(self):
        from krita import Krita
        resources = Krita.instance().resources("preset")
        entries = sorted(resources.values(), key=lambda resource: resource.name().casefold())
        blocked = self.native_presets.blockSignals(True)
        try:
            self.native_presets.clear()
            # Retain wrappers explicitly; item data contains only integers.
            self._native_resources = {index: resource for index, resource in enumerate(entries, 1)}
            self.native_presets.addItem("Current preset in Krita", None)
            window = Krita.instance().activeWindow()
            view = window.activeView() if window else None
            current = view.currentBrushPreset() if view else None
            if current is not None:
                self.native_presets.setItemIcon(0, self.preset_icon(current))
            for key, resource in self._native_resources.items():
                self.native_presets.addItem(self.preset_icon(resource), resource.name(), key)
        finally:
            self.native_presets.blockSignals(blocked)
        self.report("Loaded {} Krita presets. Native brush uses pen-up compatibility mode in this hotfix.".format(len(resources)))

    def selected_native_preset(self):
        key = self.native_presets.currentData()
        if key is None:
            return None
        resource = self._native_resources.get(key)
        if resource is None:
            raise RuntimeError("The selected preset is no longer available. Reload Krita presets.")
        return resource

    def render_native(self, stroke, preset=None):
        from .native_brush import NativeBrushBridge
        started = time.perf_counter()
        if self._native_bridge is None:
            self._native_bridge = NativeBrushBridge(reuse=True)
        # Selecting a preset in this window also selects it in Krita once.
        # Subsequent strokes avoid loading it and restoring it again per stroke.
        self.activate_native_preset(quiet=True)
        patch = self._native_bridge.render(stroke, preset)
        self._native_timings = dict(self._native_bridge.last_timings)
        self._native_timings["interaction_ms"] = (time.perf_counter() - started) * 1000
        self._native_prepare_timer.start(150)
        return patch

    def activate_native_preset(self, quiet=False):
        resource = self.selected_native_preset()
        if resource is None:
            return
        from krita import Krita
        from .native_brush import NativeBrushBridge
        window = Krita.instance().activeWindow()
        view = window.activeView() if window else None
        setter = getattr(view, "setCurrentBrushPreset", None) if view else None
        if callable(setter) and not NativeBrushBridge.same_preset(resource, view.currentBrushPreset()):
            setter(resource)
        if not quiet:
            self.report("Native preset selected: {}".format(resource.name()))
            self._native_prepare_timer.start(0)

    def prepare_native(self):
        if self.tool.currentText() != "Native brush":
            return
        if self.surface.pending is not None or self.surface._detail_session is not None or self.surface.tablet_active or self.surface.touch_active:
            self._native_prepare_timer.start(150)
            return
        try:
            from .native_brush import NativeBrushBridge
            if self._native_bridge is None:
                self._native_bridge = NativeBrushBridge(reuse=True)
            self._native_bridge.prepare()
        except Exception:
            # Preparation is optional. The regular stroke path reports errors
            # with recovery ink, without losing input or raising in a Qt slot.
            pass

    def native_timing_details(self):
        if not self._native_timings:
            self.report("Draw a native brush stroke first, then open Timing details.")
            return
        timing = self._native_timings
        self.report("Native stroke timing — document {:.0f} ms · setup {:.0f} ms · painting {:.0f} ms · capture {:.0f} ms · total {:.0f} ms".format(
            timing.get("document_ms", 0), timing.get("setup_ms", 0), timing.get("paint_ms", 0),
            timing.get("capture_ms", 0), timing.get("interaction_ms", timing.get("total_ms", 0))))

    @staticmethod
    def preset_icon(resource):
        try:
            image = resource.image()
            if image is not None and not image.isNull():
                return QIcon(QPixmap.fromImage(image))
        except (AttributeError, RuntimeError):
            pass
        return QIcon()

    def begin_live_native(self, stroke, point, preset):
        raise RuntimeError("Live native scratchpad integration was removed after a native heap-corruption crash. Use compatibility mode.")

    @pyqtSlot(object, object, object)
    def _native_completed(self, session, patch, error):
        if self.surface._native_live is session:
            self.surface._native_live = None
            self.surface._native_failure = error or "Live native stroke ended unexpectedly"
        self._native_sessions.discard(session)
        if patch is not None and session.paper.promote_generated(session.stroke, patch):
            if session.stroke in self.surface.selected:
                self.surface.selected.remove(session.stroke)
                self.surface.selected.add(patch)
            self.changed()
            self.report("Native brush: {} · live freehand".format(patch.preset))
        elif error:
            self.report("Native brush: {}. Vector recovery ink retained.".format(error))
        self.surface.update()

    def flush_native(self):
        if not self._native_sessions:
            return
        loop = QEventLoop(self)
        poll = QTimer(self)
        poll.setInterval(15)
        poll.timeout.connect(lambda: loop.quit() if not self._native_sessions else None)
        timeout = QTimer(self)
        timeout.setSingleShot(True)
        timeout.timeout.connect(loop.quit)
        self.surface.setEnabled(False)
        try:
            poll.start()
            timeout.start(2500)
            loop.exec_()
        finally:
            poll.stop()
            timeout.stop()
            poll.deleteLater()
            timeout.deleteLater()
            loop.deleteLater()
            self.surface.setEnabled(True)
        if self._native_sessions:
            raise RuntimeError("Native ink is still finishing. Please try saving again in a moment.")

    def tool_changed(self, name):
        self.surface.finish()
        self.surface.cancel_navigation()
        self.tool_actions[name].setChecked(True)
        self.surface.setCursor(Qt.OpenHandCursor if name == "Pan" else Qt.CrossCursor)
        self.surface.update()
        if name == "Native brush":
            self._native_prepare_timer.start(0)

    def selected_indices(self):
        self.surface.finish()
        self.surface.cancel_navigation()
        indices = [i for i, stroke in enumerate(self.paper.strokes) if stroke in self.surface.selected]
        if not indices:
            raise ValueError("Select one or more items first, using Select or Select all.")
        return indices

    def select_all(self):
        self.surface.finish()
        self.surface.selected = set(self.paper.strokes)
        self.tool.setCurrentText("Select")
        self.surface.update()

    def deselect(self):
        self.surface.finish()
        self.surface.selected.clear()
        self.surface.update()

    def delete_selected(self):
        self.paper.erase(self.selected_indices())
        self.surface.selected.clear()
        self.surface.update()
        self.changed()

    def duplicate_selected(self):
        indices = self.selected_indices()
        with localcontext(PRECISION):
            offset = dec(20) * self.paper.camera.unit
            copies = [translated(self.paper.strokes[i], offset, offset) for i in indices]
        self.paper.add_many(copies)
        self.surface.selected = set(copies)
        self.surface.update()
        self.changed()

    def transform_selected(self, scale=1, angle=0, mirror=False):
        indices = self.selected_indices()
        boxes = [world_bounds(self.paper.strokes[i]) for i in indices]
        with localcontext(PRECISION):
            pivot = ((min(b[0] for b in boxes) + max(b[2] for b in boxes)) / 2,
                     (min(b[1] for b in boxes) + max(b[3] for b in boxes)) / 2)
            replacements = [(i, transformed(self.paper.strokes[i], pivot, scale, angle, mirror)) for i in indices]
        self.paper.replace(replacements)
        self.surface.selected = {stroke for _, stroke in replacements}
        self.surface.update()
        self.changed()

    def scale_selected(self):
        self.selected_indices()
        value, ok = QInputDialog.getDouble(self, "Scale selection", "Scale (%):", 100, 1, 10000, 2)
        if ok:
            self.transform_selected(scale=value / 100)

    def rotate_selected(self):
        self.selected_indices()
        value, ok = QInputDialog.getDouble(self, "Rotate selection", "Angle (degrees):", 0, -360, 360, 2)
        if ok:
            self.transform_selected(angle=value)

    def choose_font(self):
        font, ok = QFontDialog.getFont(self.text_font, self, "Text font")
        if ok:
            self.text_font = font

    def insert_text(self, point, text=None):
        if text is None:
            text, ok = QInputDialog.getMultiLineText(self, "Insert vector text", "Text:")
            if not ok:
                return
        if not text or not text.strip():
            return
        if len(text) > 2000:
            raise ValueError("Limit text insertions to 2,000 characters.")
        path = QPainterPath()
        font = QFont(self.text_font)
        if font.pixelSize() < 0:
            font.setPixelSize(max(1, round(font.pointSizeF() * self.logicalDpiY() / 72)))
        line_height = font.pixelSize() * 1.35
        for index, line in enumerate(text.splitlines()):
            path.addText(QPointF(0, font.pixelSize() + index * line_height), font, line)
        contours = [[(p.x(), p.y()) for p in polygon] for polygon in path.toSubpathPolygons() if len(polygon) >= 3]
        if not contours:
            return
        origin = self.paper.camera.world(point.x(), point.y(), self.surface.width(), self.surface.height())
        shape = VectorShape(origin, self.paper.camera.unit, self.ink.name(), contours)
        self.paper.add(shape)
        self.surface.selected = {shape}
        self.surface.update()
        self.changed()

    def report(self, message):
        self.status.setText(message)

    def changed(self):
        # This is a display label, not camera arithmetic. A 384-digit logarithm
        # on every navigation event needlessly delayed input processing.
        power = -math.log10(float(self.paper.camera.unit))
        location = Path(self.paper.filename).name if self.paper.filename else "Unsaved canvas — use Save to enable autosave"
        self.status.setText("{} · {} strokes · Zoom 10^{:.2f}×{}".format(
            location, len(self.paper.strokes), power, " · unsaved changes" if self.paper.dirty else ""))
        self.setWindowTitle("{}Continuous Canvas {} — {}".format("*" if self.paper.dirty else "", VERSION, location))
        if self.paper.dirty and self.paper.filename and self.autosave.isChecked():
            self.autosave_timer.start()

    def _autosave(self):
        if self.surface.pending is not None or self.surface._detail_session is not None or self.surface.tablet_active or self.surface.touch_active:
            self.autosave_timer.start()
            return
        if self.paper.dirty and self.paper.filename and self.autosave.isChecked():
            try:
                self.paper.save()
                self.changed()
            except Exception as error:
                self.report("Autosave failed: {}. Use Save as to choose another file.".format(error))

    def save(self, save_as=False):
        self.surface.finish()
        self.flush_native()
        filename = self.paper.filename
        if save_as or not filename:
            filename, _ = QFileDialog.getSaveFileName(self, "Save Continuous Canvas", filename or "Drawing.ccanvas.json",
                                                     "Continuous Canvas (*.ccanvas.json)")
            if not filename:
                return False
            if not filename.lower().endswith(".ccanvas.json"):
                filename += ".ccanvas.json"
        self.autosave_timer.stop()
        self.paper.save(filename)
        self.changed()
        return True

    def _can_leave(self):
        self.surface.finish()
        self.flush_native()
        if not self.paper.dirty:
            return True
        choice = QMessageBox.question(self, "Save canvas?", "Save your changes before continuing?",
                                      QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel, QMessageBox.Save)
        if choice == QMessageBox.Save:
            return self.save()
        return choice == QMessageBox.Discard

    def _replace(self, paper):
        self.autosave_timer.stop()
        self.surface.cancel_navigation()
        self.paper = paper
        self.surface.selected.clear()
        self._bookmarks()
        self.surface.update()
        self.changed()

    def new(self):
        if self._can_leave():
            self._replace(Paper())

    def open(self):
        if not self._can_leave():
            return
        filename, _ = QFileDialog.getOpenFileName(self, "Open Continuous Canvas", "", "Continuous Canvas (*.ccanvas.json);;All files (*)")
        if filename:
            self._replace(Paper.load(filename))

    def color(self):
        value = QColorDialog.getColor(self.ink, self, "Choose pen color")
        if value.isValid():
            self.set_ink(value)

    def undo(self):
        self.surface.finish()
        self.surface.cancel_navigation()
        self.paper.undo()
        self.surface.selected.clear()
        self.surface.update()
        self.changed()

    def redo(self):
        self.surface.finish()
        self.surface.cancel_navigation()
        self.paper.redo()
        self.surface.selected.clear()
        self.surface.update()
        self.changed()

    def bookmark(self):
        self.surface.finish()
        if len(self.paper.bookmarks) >= 1000:
            raise ValueError("Maximum 1000 bookmarks per canvas.")
        name, ok = QInputDialog.getText(self, "Save this view", "Bookmark name:")
        if ok and name.strip():
            self.paper.bookmarks.append({"name": name.strip()[:200], "camera": self.paper.camera.data()})
            self.paper.dirty = True
            self._bookmarks()
            self.bookmarks.setCurrentIndex(self.bookmarks.count() - 1)
            self.changed()

    def _bookmarks(self):
        self.bookmarks.clear()
        self.bookmarks.addItems([bookmark["name"] for bookmark in self.paper.bookmarks])

    def go_bookmark(self):
        self.surface.finish()
        self.surface.cancel_navigation()
        index = self.bookmarks.currentIndex()
        if index >= 0:
            self.paper.camera = Camera(*self.paper.bookmarks[index]["camera"])
            self.paper.dirty = True
            self.surface.update()
            self.changed()

    def home(self):
        self.surface.finish()
        self.surface.cancel_navigation()
        self.paper.camera = Camera()
        self.paper.dirty = True
        self.surface.update()
        self.changed()

    def export_png(self):
        self.surface.finish()
        filename, _ = QFileDialog.getSaveFileName(self, "Export the current view", "Canvas-view.png", "PNG image (*.png)")
        if not filename:
            return
        if not filename.lower().endswith(".png"):
            filename += ".png"
        image = QImage(self.surface.width(), self.surface.height(), QImage.Format_ARGB32)
        painter = QPainter(image)
        try:
            self.surface.render(painter, image.width(), image.height())
        finally:
            painter.end()
        if not image.save(filename, "PNG"):
            raise OSError("Could not write the PNG image.")
        self.report("Exported current view: {}. Keep the .ccanvas.json file for editable deep zoom.".format(filename))

    def open_raster_copy(self):
        import tempfile
        from krita import Krita
        self.surface.finish()
        image = QImage(self.surface.width(), self.surface.height(), QImage.Format_ARGB32)
        painter = QPainter(image)
        try:
            self.surface.render(painter, image.width(), image.height())
        finally:
            painter.end()
        with tempfile.NamedTemporaryFile(prefix="continuous-canvas-view-", suffix=".png", delete=False) as output:
            filename = output.name
        if not image.save(filename, "PNG"):
            raise OSError("Could not create the raster copy.")
        app = Krita.instance()
        document = app.openDocument(filename)
        if document is None:
            raise RuntimeError("Krita could not open the raster copy.")
        app.activeWindow().addView(document)
        self.hide()
        self.report("Opened a raster copy in Krita. Native brush edits stay in that separate document; save it as .kra.")

    def reject(self):
        self.close()

    def closeEvent(self, event):
        if self.surface._erase_busy:
            event.ignore()
            return
        try:
            if self._can_leave():
                self.surface.cancel_navigation()
                self.autosave_timer.stop()
                self._native_prepare_timer.stop()
                if self._native_bridge is not None:
                    try:
                        self._native_bridge.close()
                    except Exception as error:
                        self.report("Native render document cleanup: " + str(error))
                if self._native_host_document is not None:
                    self._native_host_document.setModified(False)
                    self._native_host_document.close()
                    self._native_host_document = None
                event.accept()
            else:
                event.ignore()
        except Exception as error:
            self.report("Could not close safely: {}".format(error))
            event.ignore()
