"""Vector document and high precision camera, independent of Qt/Krita.

Strokes retain a high precision origin and drawing scale; their points remain
small local numbers. Viewport clipping happens before conversion to Qt floats.
"""
from decimal import Context, Decimal, localcontext
import json
import math
from pathlib import Path
import re
import shutil
import base64
import struct

PRECISION = Context(prec=384)
MIN_UNIT, MAX_UNIT = Decimal("1e-120"), Decimal("1e120")
MAX_COORD = Decimal("1e140")
CIRCLE = tuple((math.cos(i * math.tau / 48), math.sin(i * math.tau / 48)) for i in range(48))


def dec(value):
    value = Decimal(str(value))
    if not value.is_finite():
        raise ValueError("Coordinates must be finite.")
    return value


def number(value, low, high):
    result = float(value)
    if not math.isfinite(result) or not low <= result <= high:
        raise ValueError("Invalid numeric value.")
    return result


class Camera:
    def __init__(self, x="0", y="0", unit="1"):
        self.x, self.y, self.unit = dec(x), dec(y), dec(unit)
        if abs(self.x) > MAX_COORD or abs(self.y) > MAX_COORD or not MIN_UNIT <= self.unit <= MAX_UNIT:
            raise ValueError("View is outside the supported coordinate range.")

    def data(self):
        return [str(self.x), str(self.y), str(self.unit)]

    def world(self, sx, sy, width, height):
        with localcontext(PRECISION):
            return (self.x + dec(sx - width / 2) * self.unit,
                    self.y + dec(sy - height / 2) * self.unit)

    def pan(self, dx, dy):
        with localcontext(PRECISION):
            self.x = max(-MAX_COORD, min(MAX_COORD, self.x - dec(dx) * self.unit))
            self.y = max(-MAX_COORD, min(MAX_COORD, self.y - dec(dy) * self.unit))

    def zoom(self, factor, sx, sy, width, height):
        factor = number(factor, 0.001, 1000)
        with localcontext(PRECISION):
            wx, wy = self.world(sx, sy, width, height)
            new_unit = max(MIN_UNIT, min(MAX_UNIT, self.unit / dec(factor)))
            if new_unit == self.unit:
                return
            x = wx - dec(sx - width / 2) * new_unit
            y = wy - dec(sy - height / 2) * new_unit
            if abs(x) > MAX_COORD or abs(y) > MAX_COORD:
                return
            self.x, self.y, self.unit = x, y, new_unit


def clip_polygon(polygon, left, top, right, bottom):
    """Sutherland–Hodgman, with either float or Decimal coordinates."""
    output = list(polygon)
    for axis, bound, keep_greater in ((0, left, True), (0, right, False),
                                     (1, top, True), (1, bottom, False)):
        incoming, output = output, []
        if not incoming:
            break
        a = incoming[-1]
        a_inside = a[axis] >= bound if keep_greater else a[axis] <= bound
        for b in incoming:
            b_inside = b[axis] >= bound if keep_greater else b[axis] <= bound
            if a_inside != b_inside:
                fraction = (bound - a[axis]) / (b[axis] - a[axis])
                cross = (a[0] + fraction * (b[0] - a[0]), a[1] + fraction * (b[1] - a[1]))
                # Pin the clipped component exactly, avoiding decimal roundoff.
                output.append((bound, cross[1]) if axis == 0 else (cross[0], bound))
            if b_inside:
                output.append(b)
            a, a_inside = b, b_inside
    return output


class Stroke:
    def __init__(self, origin, unit, width, color, points):
        self.origin = (dec(origin[0]), dec(origin[1]))
        self.unit = dec(unit)
        if any(abs(v) > MAX_COORD for v in self.origin) or not MIN_UNIT <= self.unit <= MAX_UNIT:
            raise ValueError("Stroke is outside the supported range.")
        self.width = number(width, 0.1, 500)
        if not isinstance(color, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
            raise ValueError("Invalid stroke color.")
        self.color = color
        if not points or len(points) > 100000:
            raise ValueError("Invalid stroke point count.")
        self.points = [(number(p[0], -1e7, 1e7), number(p[1], -1e7, 1e7),
                        number(p[2], 0.05, 1)) for p in points]
        self._update_bounds()

    def _update_bounds(self):
        xs, ys = [p[0] for p in self.points], [p[1] for p in self.points]
        r = self.width / 2
        self.bounds = (min(xs) - r, min(ys) - r, max(xs) + r, max(ys) + r)

    def append(self, x, y, pressure):
        if len(self.points) >= 100000:
            return
        x, y, pressure = number(x, -1e7, 1e7), number(y, -1e7, 1e7), number(pressure, 0.05, 1)
        self.points.append((x, y, pressure))
        l, t, r, b = self.bounds
        radius = self.width / 2
        self.bounds = (min(l, x - radius), min(t, y - radius), max(r, x + radius), max(b, y + radius))

    def data(self):
        return {"origin": [str(v) for v in self.origin], "unit": str(self.unit),
                "width": self.width, "color": self.color, "points": self.points}

    def polygons(self, start=0, clip_bounds=None):
        def visible(left, top, right, bottom):
            return (clip_bounds is None or
                    (right >= clip_bounds[0] and bottom >= clip_bounds[1] and
                     left <= clip_bounds[2] and top <= clip_bounds[3]))
        previous = None
        if start:
            px, py, pressure = self.points[start - 1]
            previous = (px, py, self.width * pressure / 2)
        for index in range(start, len(self.points)):
            x, y, pressure = self.points[index]
            radius = self.width * pressure / 2
            if previous is not None:
                px, py, pr = previous
                dx, dy = x - px, y - py
                length = math.hypot(dx, dy)
                extent = max(pr, radius)
                if length > 1e-12 and visible(min(px, x) - extent, min(py, y) - extent,
                                             max(px, x) + extent, max(py, y) + extent):
                    nx, ny = -dy / length, dx / length
                    yield [(px + nx * pr, py + ny * pr), (px - nx * pr, py - ny * pr),
                           (x - nx * radius, y - ny * radius), (x + nx * radius, y + ny * radius)]
            if visible(x - radius, y - radius, x + radius, y + radius):
                yield [(x + cx * radius, y + cy * radius) for cx, cy in CIRCLE]
            previous = (x, y, radius)

    def screen_polygons(self, camera, width, height):
        with localcontext(PRECISION):
            ox = (self.origin[0] - camera.x) / camera.unit + dec(width / 2)
            oy = (self.origin[1] - camera.y) / camera.unit + dec(height / 2)
            ratio = self.unit / camera.unit
            l, t, r, b = self.bounds
            if (ox + dec(r) * ratio < 0 or oy + dec(b) * ratio < 0 or
                    ox + dec(l) * ratio > width or oy + dec(t) * ratio > height):
                return
            # Normal drawing uses small floats; extreme zoom is clipped using
            # Decimal before it ever reaches Qt's raster coordinate limits.
            fast = (abs(ox) < Decimal("1e7") and abs(oy) < Decimal("1e7") and
                    Decimal("1e-7") < ratio < Decimal("1e6"))
            # Cull segments/caps in local coordinates BEFORE constructing and
            # high-precision clipping all 48 cap vertices. Round bounds outward
            # so this conservative test never discards visible geometry.
            local_clip = (
                math.nextafter(float((Decimal(-1) - ox) / ratio), -math.inf),
                math.nextafter(float((Decimal(-1) - oy) / ratio), -math.inf),
                math.nextafter(float((dec(width + 1) - ox) / ratio), math.inf),
                math.nextafter(float((dec(height + 1) - oy) / ratio), math.inf))
            if fast:
                fx, fy, scale = float(ox), float(oy), float(ratio)
                for polygon in self.polygons(clip_bounds=local_clip):
                    points = [(fx + x * scale, fy + y * scale) for x, y in polygon]
                    clipped = clip_polygon(points, -1.0, -1.0, width + 1.0, height + 1.0)
                    if len(clipped) >= 3:
                        yield clipped
            else:
                for polygon in self.polygons(clip_bounds=local_clip):
                    points = [(ox + dec(x) * ratio, oy + dec(y) * ratio) for x, y in polygon]
                    clipped = clip_polygon(points, Decimal(-1), Decimal(-1), dec(width + 1), dec(height + 1))
                    if len(clipped) >= 3:
                        yield [(float(x), float(y)) for x, y in clipped]

    def hit(self, camera, sx, sy, width, height, radius=8):
        with localcontext(PRECISION):
            wx, wy = camera.world(sx, sy, width, height)
            x, y = (wx - self.origin[0]) / self.unit, (wy - self.origin[1]) / self.unit
            eraser = dec(radius) * camera.unit / self.unit
            l, t, r, b = map(dec, self.bounds)
            if x + eraser < l or x - eraser > r or y + eraser < t or y - eraser > b:
                return False
            for index, point in enumerate(self.points):
                bx, by, bp = map(dec, point)
                ax, ay, ap = map(dec, self.points[max(0, index - 1)])
                dx, dy = bx - ax, by - ay
                length2 = dx * dx + dy * dy
                u = max(Decimal(0), min(Decimal(1), ((x - ax) * dx + (y - ay) * dy) / length2)) if length2 else Decimal(0)
                distance2 = (x - ax - u * dx) ** 2 + (y - ay - u * dy) ** 2
                stroke_radius = dec(self.width / 2) * (ap + (bp - ap) * u)
                if distance2 <= (stroke_radius + eraser) ** 2:
                    return True
        return False


class VectorShape(Stroke):
    """Immutable filled contours, used for text outlines and filled shapes."""
    fill_rule = "odd_even"

    def __init__(self, origin, unit, color, contours):
        if not contours or any(len(contour) < 3 for contour in contours):
            raise ValueError("A vector shape needs closed contours.")
        flat = [point for contour in contours for point in contour]
        super().__init__(origin, unit, 0.1, color, [(p[0], p[1], 1) for p in flat])
        self.contours = [[(number(p[0], -1e7, 1e7), number(p[1], -1e7, 1e7)) for p in contour] for contour in contours]

    def polygons(self, start=0, clip_bounds=None):
        if not start:
            yield from self.contours

    def data(self):
        return {"type": "shape", "origin": [str(v) for v in self.origin],
                "unit": str(self.unit), "color": self.color, "contours": self.contours}

    def hit(self, camera, sx, sy, width, height, radius=8):
        with localcontext(PRECISION):
            wx, wy = camera.world(sx, sy, width, height)
            x, y = (wx - self.origin[0]) / self.unit, (wy - self.origin[1]) / self.unit
            inside = False
            for contour in self.contours:
                ax, ay = map(dec, contour[-1])
                for point in contour:
                    bx, by = map(dec, point)
                    if (ay > y) != (by > y) and x < ax + (y - ay) * (bx - ax) / (by - ay):
                        inside = not inside
                    ax, ay = bx, by
            return inside


class RasterPatch(VectorShape):
    """A native-brush result, anchored at the scale where it was painted."""
    def __init__(self, origin, unit, width, height, png, contours=None, preset="", mode=""):
        if type(width) is not int or type(height) is not int or not 1 <= width <= 4096 or not 1 <= height <= 4096:
            raise ValueError("Native patch dimensions are invalid.")
        if not isinstance(png, str) or len(png) > 24 * 1024 * 1024:
            raise ValueError("Native patch exceeds the image limit.")
        raw = base64.b64decode(png, validate=True)
        if len(raw) < 33 or raw[:8] != b"\x89PNG\r\n\x1a\n" or raw[12:16] != b"IHDR" or struct.unpack(">II", raw[16:24]) != (width, height):
            raise ValueError("Native patch PNG header does not match its dimensions.")
        contours = contours or [[(0, 0), (width, 0), (width, height), (0, height)]]
        if len(contours) != 1 or len(contours[0]) != 4:
            raise ValueError("Native patch needs four placement corners.")
        super().__init__(origin, unit, "#000000", contours)
        self.pixel_width, self.pixel_height, self.png = width, height, png
        self.preset, self.mode = str(preset)[:300], str(mode)[:100]

    def data(self):
        return {"type": "native_patch", "origin": [str(v) for v in self.origin],
                "unit": str(self.unit), "width": self.pixel_width, "height": self.pixel_height,
                "png": self.png, "contours": self.contours, "preset": self.preset, "mode": self.mode}


def element_from_data(data):
    if data.get("type") == "native_patch":
        return RasterPatch(data["origin"], data["unit"], data["width"], data["height"],
                           data["png"], data["contours"], data.get("preset", ""), data.get("mode", ""))
    if data.get("type") == "shape":
        return VectorShape(data["origin"], data["unit"], data["color"], data["contours"])
    return Stroke(data["origin"], data["unit"], data["width"], data["color"], data["points"])


class Paper:
    def __init__(self):
        self.camera = Camera()
        self.strokes = []
        self.bookmarks = []
        self.undo_stack = []
        self.redo_stack = []
        self.filename = None
        self.dirty = False
        self.revision = 0
        self.last_change = None

    def add(self, stroke):
        self.add_many([stroke])

    def add_many(self, strokes):
        if not strokes:
            return
        if len(self.strokes) + len(strokes) > 50000 or sum(len(s.points) for s in self.strokes) + sum(len(s.points) for s in strokes) > 500000:
            raise ValueError("Canvas limit reached (50,000 strokes / 500,000 points). Save a copy before continuing elsewhere.")
        records = [(len(self.strokes) + index, stroke) for index, stroke in enumerate(strokes)]
        self.strokes.extend(strokes)
        self.undo_stack.append(("add", records))
        self.redo_stack.clear()
        self.dirty = True
        self.revision += 1
        self.last_change = ("add", strokes[0]) if len(strokes) == 1 else ("rebuild", None)

    def erase(self, indices):
        removed = [(i, self.strokes[i]) for i in sorted(set(indices))]
        if not removed:
            return
        for i, _ in reversed(removed):
            del self.strokes[i]
        self.undo_stack.append(("erase", removed))
        self.redo_stack.clear()
        self.dirty = True
        self.revision += 1
        self.last_change = ("rebuild", None)

    def undo(self):
        if not self.undo_stack:
            return
        action, items = self.undo_stack.pop()
        if action == "add":
            for index, _ in reversed(items):
                del self.strokes[index]
        elif action == "replace":
            for index, old, new in items:
                self.strokes[index] = old
        else:
            for index, stroke in items:
                self.strokes.insert(index, stroke)
        self.redo_stack.append((action, items))
        self.dirty = True
        self.revision += 1
        self.last_change = ("rebuild", None)

    def redo(self):
        if not self.redo_stack:
            return
        action, items = self.redo_stack.pop()
        if action == "add":
            for index, stroke in items:
                self.strokes.insert(index, stroke)
        elif action == "replace":
            for index, old, new in items:
                self.strokes[index] = new
        else:
            for index, _ in reversed(items):
                del self.strokes[index]
        self.undo_stack.append((action, items))
        self.dirty = True
        self.revision += 1
        self.last_change = ("rebuild", None)

    def replace(self, replacements):
        records = [(index, self.strokes[index], replacement) for index, replacement in replacements]
        if not records:
            return
        total = sum(len(s.points) for s in self.strokes)
        total += sum(len(new.points) - len(old.points) for _, old, new in records)
        if total > 500000:
            raise ValueError("Canvas point limit exceeded.")
        for index, old, new in records:
            self.strokes[index] = new
        self.undo_stack.append(("replace", records))
        self.redo_stack.clear()
        self.revision += 1
        self.last_change = ("rebuild", None)
        self.dirty = True

    def promote_generated(self, old, new):
        """Finish an asynchronous brush stroke as the original single undo step."""
        index = next((i for i, s in enumerate(self.strokes) if s is old), None)
        if index is None:
            return False  # Undone, erased, or transformed while rendering.
        self.strokes[index] = new
        for stack in (self.undo_stack, self.redo_stack):
            for position, (action, records) in enumerate(stack):
                if action == "replace":
                    records = [(i, new if a is old else a, new if b is old else b) for i, a, b in records]
                else:
                    records = [(i, new if s is old else s) for i, s in records]
                stack[position] = (action, records)
        self.revision += 1
        self.last_change = ("rebuild", None)
        self.dirty = True
        return True

    def save(self, filename=None):
        if filename is None and self.filename is None:
            raise ValueError("Choose a project filename first.")
        path = Path(filename or self.filename).resolve()
        version = 3 if any(isinstance(s, RasterPatch) for s in self.strokes) else (2 if any(isinstance(s, VectorShape) for s in self.strokes) else 1)
        data = {"format": "continuous-vector-canvas", "version": version,
                "camera": self.camera.data(), "bookmarks": self.bookmarks,
                "strokes": [stroke.data() for stroke in self.strokes]}
        payload = json.dumps(data, separators=(",", ":"), allow_nan=False)
        if len(payload.encode("utf-8")) > 100 * 1024 * 1024:
            raise ValueError("Project exceeds this release's 100 MB file limit.")
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_text(payload, encoding="utf-8")
        if path.exists():
            shutil.copy2(path, path.with_name(path.name + ".bak"))
        temporary.replace(path)
        self.filename = str(path)
        self.dirty = False

    @classmethod
    def load(cls, filename):
        path = Path(filename)
        if path.stat().st_size > 100 * 1024 * 1024:
            raise ValueError("Project is larger than 100 MB.")
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("format") != "continuous-vector-canvas" or data.get("version") not in (1, 2, 3):
            raise ValueError("Not a supported Continuous Canvas project.")
        result = cls()
        result.camera = Camera(*data["camera"])
        strokes = data["strokes"]
        def point_count(s):
            if s.get("type") == "native_patch":
                return 4
            return sum(len(c) for c in s["contours"]) if s.get("type") == "shape" else len(s["points"])
        if len(strokes) > 50000 or sum(point_count(s) for s in strokes) > 500000:
            raise ValueError("Project exceeds this release's stroke/point limit.")
        result.strokes = [element_from_data(s) for s in strokes]
        bookmarks = data.get("bookmarks", [])
        if len(bookmarks) > 1000:
            raise ValueError("Too many bookmarks.")
        for bookmark in bookmarks:
            if not isinstance(bookmark["name"], str) or len(bookmark["name"]) > 200:
                raise ValueError("Invalid bookmark name.")
            Camera(*bookmark["camera"])
        result.bookmarks = bookmarks
        result.filename = str(path.resolve())
        return result
