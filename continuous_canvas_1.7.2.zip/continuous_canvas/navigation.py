"""Render exact navigation frames off the GUI thread, one job at a time."""
import math
import threading

from PyQt5.QtCore import QObject, QRunnable, QThreadPool, Qt, pyqtSignal, pyqtSlot
from PyQt5.QtGui import QColor, QImage, QPainter, QPainterPath

from .rendering import VectorRenderer


class _Signals(QObject):
    ready = pyqtSignal(object)


class _FrameJob(QRunnable):
    def __init__(self, signals, renderer, ticket, strokes, camera, width, height, ratio):
        super().__init__()
        self.signals, self.renderer, self.ticket = signals, renderer, ticket
        self.strokes, self.camera = strokes, camera
        self.width, self.height, self.ratio = width, height, ratio
        self.cancelled = threading.Event()

    def run(self):
        result = {"ticket": self.ticket, "camera": self.camera, "image": None}
        painter = None
        try:
            image = QImage(math.ceil(self.width * self.ratio), math.ceil(self.height * self.ratio), QImage.Format_RGB32)
            image.setDevicePixelRatio(self.ratio)
            image.fill(QColor("white"))
            painter = QPainter(image)
            painter.setRenderHint(QPainter.Antialiasing, True)
            painter.setPen(Qt.NoPen)
            for stroke in self.strokes:
                if self.cancelled.is_set():
                    break
                self.renderer.draw(painter, stroke, self.camera, self.width, self.height)
            if not self.cancelled.is_set():
                result["image"] = image
        except Exception as error:
            result["error"] = str(error)
        finally:
            if painter is not None:
                painter.end()
            self.signals.ready.emit(result)


class FrameRenderer(QObject):
    completed = pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.pool = QThreadPool(self)
        self.pool.setMaxThreadCount(1)
        self.renderer = VectorRenderer()
        self.signals = _Signals()
        self.signals.ready.connect(self._finished)
        self.job = None

    def start(self, ticket, strokes, camera, width, height, ratio, source_renderer):
        if self.job is not None:
            return False
        # Completed strokes are immutable. Copy retained Qt paths (implicitly
        # shared by Qt), never a mutable pending path or a GUI-owned dictionary.
        for stroke in strokes:
            if stroke not in self.renderer.paths:
                cached = source_renderer.paths.get(stroke)
                if cached is not None and cached[1] == len(stroke.points):
                    self.renderer.paths[stroke] = (QPainterPath(cached[0]), cached[1])
        self.job = _FrameJob(self.signals, self.renderer, ticket, strokes, camera, width, height, ratio)
        self.pool.start(self.job)
        return True

    def cancel(self):
        if self.job is not None:
            self.job.cancelled.set()

    @pyqtSlot(object)
    def _finished(self, result):
        self.job = None
        self.completed.emit(result)
