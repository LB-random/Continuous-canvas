from krita import Krita, Extension, DockWidgetFactory, DockWidgetFactoryBase
from .launcher import CanvasLauncher, CanvasDock

Krita.instance().addExtension(CanvasLauncher(Krita.instance()))
Krita.instance().addDockWidgetFactory(DockWidgetFactory(
    "continuous_canvas_docker", DockWidgetFactoryBase.DockRight, CanvasDock))
